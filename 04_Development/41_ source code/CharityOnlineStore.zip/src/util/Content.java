package util;

public class Content {
	// public final String userSession="user";

	public static final String USER_SESSION = "user";

	public static final String MESSAGE = "#MESSAGE";

	public static final int COMMODITY_STATE_SOLD = 1;

	public static final int COMMODITY_STATE_SELLING = 2;

	public static final int COMMODITY_STATE_DELETED = 3;

	public static final int FEMALE = 1;

	public static final int MALE = 2;

	public static final int Admin_YES = 1;

	public static final int Admin_NO = 2;

	public static final int USER_STATE_ENABLE = 1;

	public static final int USER_STATE_DISABLE = 2;

	public static final int PICK_UP_STATE_APPOINTED = 3;

	public static final int PICK_UP_STATE_NO = 2;

	public static final int PICK_UP_STATE_YES = 1;

	public static final int CART_STATE_ACTIVE = 1;

	public static final int CART_STATE_DELETED = 2;

}
